create
  definer = root@localhost procedure getcount(OUT total int)
begin
    select count(*) into total from student;
end;

