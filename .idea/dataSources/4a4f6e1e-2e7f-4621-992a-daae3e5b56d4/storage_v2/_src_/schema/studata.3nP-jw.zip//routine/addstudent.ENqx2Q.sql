create
  definer = root@localhost procedure addstudent(IN no char(9), IN name char(12), IN sex char(2), IN age int,
                                                IN dept char(50))
begin
    insert into student(sno, sname, sex, age, dept) values (no,name,sex,age,dept);
end;

